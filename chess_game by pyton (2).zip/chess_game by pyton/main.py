import pygame
import sys
import json
import time
from copy import deepcopy
from math import sin, cos
from pygame.locals import *

# Constants
WIDTH, HEIGHT = 1000, 800
ROWS, COLS = 8, 8
SQUARE_SIZE = HEIGHT // COLS
COLORS = {
    'white': (238, 238, 210),
    'black': (118, 150, 86),
    'highlight': (255, 255, 0, 100),
    'arrow': (255, 200, 0),
    'clock': (40, 40, 40),
    'text': (30, 30, 30)
}

# Load opening book
with open('opening_book.json') as f:
    OPENING_BOOK = json.load(f)

class ChessGame:
    def __init__(self):
        self.board = self.create_initial_board()
        self.current_turn = 'white'
        self.selected_piece = None
        self.valid_moves = []
        self.move_history = []
        self.redo_stack = []
        self.en_passant_target = None
        self.castling_rights = {'white': [True, True], 'black': [True, True]}
        self.ai_enabled = False
        self.ai_color = 'black'
        self.game_over = False
        self.animating_piece = None
        self.white_time = 600  # 10 minutes in seconds
        self.black_time = 600
        self.last_clock_update = time.time()
        self.current_opening = None
        self.suggested_moves = []
        self.move_sequence_uci = []
        
        # Sound setup
        pygame.mixer.init()
        self.sounds = {
            'move': pygame.mixer.Sound('sounds/move.wav'),
            'capture': pygame.mixer.Sound('sounds/capture.wav'),
            'check': pygame.mixer.Sound('sounds/check.wav')
        }

    def create_initial_board(self):
        return [
            ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
            ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
            ['.', '.', '.', '.', '.', '.', '.', '.'],
            ['.', '.', '.', '.', '.', '.', '.', '.'],
            ['.', '.', '.', '.', '.', '.', '.', '.'],
            ['.', '.', '.', '.', '.', '.', '.', '.'],
            ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
            ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R']
        ]

    # Core game logic
    def is_valid_position(self, row, col):
        return 0 <= row < ROWS and 0 <= col < COLS

    def is_opponent(self, piece, color):
        if piece == '.': return False
        return (color == 'white' and piece.islower()) or \
               (color == 'black' and piece.isupper())

    def get_valid_moves(self, row, col):
        piece = self.board[row][col]
        if piece == '.': return []
        color = 'white' if piece.isupper() else 'black'
        moves = []

        # Pawn moves
        if piece.lower() == 'p':
            direction = -1 if color == 'white' else 1
            start_row = 6 if color == 'white' else 1
            
            # Forward moves
            if self.is_valid_position(row+direction, col) and self.board[row+direction][col] == '.':
                moves.append((row+direction, col))
                if row == start_row and self.board[row+2*direction][col] == '.':
                    moves.append((row+2*direction, col))

            # Captures
            for dc in [-1, 1]:
                if self.is_valid_position(row+direction, col+dc):
                    target = self.board[row+direction][col+dc]
                    if target != '.' and self.is_opponent(target, color):
                        moves.append((row+direction, col+dc))
                    if (row+direction, col+dc) == self.en_passant_target:
                        moves.append((row+direction, col+dc))

        # Knight moves
        elif piece.lower() == 'n':
            for dr, dc in [(-2,-1), (-2,1), (-1,-2), (-1,2), (1,-2), (1,2), (2,-1), (2,1)]:
                new_r, new_c = row+dr, col+dc
                if self.is_valid_position(new_r, new_c):
                    target = self.board[new_r][new_c]
                    if target == '.' or self.is_opponent(target, color):
                        moves.append((new_r, new_c))

        # Bishop moves
        elif piece.lower() == 'b':
            for dr, dc in [(-1,-1), (-1,1), (1,-1), (1,1)]:
                for i in range(1, 8):
                    new_r, new_c = row+dr*i, col+dc*i
                    if not self.is_valid_position(new_r, new_c): break
                    target = self.board[new_r][new_c]
                    if target == '.':
                        moves.append((new_r, new_c))
                    else:
                        if self.is_opponent(target, color):
                            moves.append((new_r, new_c))
                        break

        # Rook moves
        elif piece.lower() == 'r':
            for dr, dc in [(-1,0), (1,0), (0,-1), (0,1)]:
                for i in range(1, 8):
                    new_r, new_c = row+dr*i, col+dc*i
                    if not self.is_valid_position(new_r, new_c): break
                    target = self.board[new_r][new_c]
                    if target == '.':
                        moves.append((new_r, new_c))
                    else:
                        if self.is_opponent(target, color):
                            moves.append((new_r, new_c))
                        break

        # Queen moves (combine rook and bishop)
        elif piece.lower() == 'q':
            moves = self.get_valid_moves(row, col, 'r') + \
                    self.get_valid_moves(row, col, 'b')

        # King moves
        elif piece.lower() == 'k':
            for dr in [-1,0,1]:
                for dc in [-1,0,1]:
                    if dr == 0 and dc == 0: continue
                    new_r, new_c = row+dr, col+dc
                    if self.is_valid_position(new_r, new_c):
                        target = self.board[new_r][new_c]
                        if target == '.' or self.is_opponent(target, color):
                            moves.append((new_r, new_c))

            # Castling
            if color == 'white' and 'K' in self.board[7][4]:
                if self.castling_rights['white'][0]:  # Queenside
                    if self.board[7][1] == '.' and self.board[7][2] == '.' and self.board[7][3] == '.':
                        moves.append((7, 2))
                if self.castling_rights['white'][1]:  # Kingside
                    if self.board[7][5] == '.' and self.board[7][6] == '.':
                        moves.append((7, 6))

        return moves

    # Game state management
    def make_move(self, start, end, simulation=False):
        if self.animating_piece or self.game_over:
            return False

        start_row, start_col = start
        end_row, end_col = end
        piece = self.board[start_row][start_col]
        captured = self.board[end_row][end_col]

        # Handle special moves
        if piece.lower() == 'k' and abs(start_col - end_col) == 2:
            # Castling
            rook_col = 7 if end_col == 6 else 0
            new_rook_col = 5 if end_col == 6 else 3
            self.board[end_row][new_rook_col] = self.board[end_row][rook_col]
            self.board[end_row][rook_col] = '.'

        if piece.lower() == 'p':
            # En passant
            if (end_row, end_col) == self.en_passant_target:
                captured_pawn_row = end_row + 1 if piece.isupper() else end_row - 1
                self.board[captured_pawn_row][end_col] = '.'
            
            # Promotion
            if end_row in [0, 7]:
                self.board[start_row][start_col] = 'Q' if piece.isupper() else 'q'

        # Update board state
        self.board[end_row][end_col] = piece
        self.board[start_row][start_col] = '.'

        if not simulation:
            # Update game state
            self.move_history.append(self.save_state())
            self.redo_stack = []
            self.current_turn = 'black' if self.current_turn == 'white' else 'white'
            self.update_opening_suggestions()
            self.start_animation(start, end)
            
            # Play sound
            if captured != '.':
                self.sounds['capture'].play()
            else:
                self.sounds['move'].play()

        return True

    # AI implementation
    def ai_move(self):
        _, best_move = self.minimax(3, -float('inf'), float('inf'), True)
        if best_move:
            self.make_move(best_move[0], best_move[1])

    def minimax(self, depth, alpha, beta, maximizing):
        if depth == 0 or self.game_over:
            return self.evaluate_board(), None

        best_move = None
        if maximizing:
            max_eval = -float('inf')
            for move in self.get_all_legal_moves(self.ai_color):
                state = self.save_state()
                self.make_move(move[0], move[1], simulation=True)
                evaluation, _ = self.minimax(depth-1, alpha, beta, False)
                self.load_state(state)
                
                if evaluation > max_eval:
                    max_eval = evaluation
                    best_move = move
                alpha = max(alpha, evaluation)
                if beta <= alpha:
                    break
            return max_eval, best_move
        else:
            min_eval = float('inf')
            for move in self.get_all_legal_moves('white'):
                state = self.save_state()
                self.make_move(move[0], move[1], simulation=True)
                evaluation, _ = self.minimax(depth-1, alpha, beta, True)
                self.load_state(state)
                
                if evaluation < min_eval:
                    min_eval = evaluation
                    best_move = move
                beta = min(beta, evaluation)
                if beta <= alpha:
                    break
            return min_eval, best_move

    def evaluate_board(self):
        score = 0
        piece_values = {'p': 1, 'n': 3, 'b': 3, 'r': 5, 'q': 9, 'k': 100}
        for r in range(8):
            for c in range(8):
                piece = self.board[r][c]
                if piece != '.':
                    value = piece_values[piece.lower()]
                    score += value if piece.isupper() else -value
        return score

    # Save/load system
    def save_state(self):
        return {
            'board': deepcopy(self.board),
            'current_turn': self.current_turn,
            'castling': deepcopy(self.castling_rights),
            'en_passant': self.en_passant_target,
            'clock': (self.white_time, self.black_time)
        }

    def load_state(self, state):
        self.board = deepcopy(state['board'])
        self.current_turn = state['current_turn']
        self.castling_rights = deepcopy(state['castling'])
        self.en_passant_target = state['en_passant']
        self.white_time, self.black_time = state['clock']

    # Opening book integration
    def to_uci(self, start, end):
        start_row, start_col = start
        end_row, end_col = end
        return f"{'abcdefgh'[start_col]}{8-start_row}{'abcdefgh'[end_col]}{8-end_row}"

    def update_opening_suggestions(self):
        self.current_opening = None
        self.suggested_moves = []
        current_sequence = ','.join(self.move_sequence_uci)
        
        for length in range(len(self.move_sequence_uci), 0, -1):
            partial_sequence = ','.join(self.move_sequence_uci[:length])
            if partial_sequence in OPENING_BOOK:
                self.current_opening = OPENING_BOOK[partial_sequence]['name']
                self.suggested_moves = OPENING_BOOK[partial_sequence]['moves']
                break

    # Animation system
    def start_animation(self, start, end):
        self.animating_piece = {
            'start': start,
            'end': end,
            'piece': self.board[start[0]][start[1]],
            'progress': 0.0
        }

    def update_animation(self):
        if self.animating_piece:
            self.animating_piece['progress'] += 0.08
            if self.animating_piece['progress'] >= 1.0:
                self.animating_piece = None

    def get_animated_position(self):
        if not self.animating_piece:
            return None
            
        start_row, start_col = self.animating_piece['start']
        end_row, end_col = self.animating_piece['end']
        progress = self.animating_piece['progress']
        eased_progress = 0.5 - 0.5 * cos(progress * 3.14159)
        
        x = start_col * SQUARE_SIZE + (end_col - start_col) * SQUARE_SIZE * eased_progress
        y = start_row * SQUARE_SIZE + (end_row - start_row) * SQUARE_SIZE * eased_progress
        
        return (x, y)

    # Chess clock
    def update_clocks(self):
        if self.game_over: return
        current_time = time.time()
        elapsed = current_time - self.last_clock_update
        self.last_clock_update = current_time
        
        if self.current_turn == 'white':
            self.white_time -= elapsed
        else:
            self.black_time -= elapsed
            
        if self.white_time <= 0 or self.black_time <= 0:
            self.game_over = True

    def format_time(self, seconds):
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes:02d}:{secs:02d}"

    # Drawing methods
    def draw_board(self, screen):
        for row in range(ROWS):
            for col in range(COLS):
                color = COLORS['white'] if (row + col) % 2 == 0 else COLORS['black']
                pygame.draw.rect(screen, color, 
                    (col*SQUARE_SIZE, row*SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))

    def draw_pieces(self, screen):
        # Regular pieces
        for row in range(ROWS):
            for col in range(COLS):
                piece = self.board[row][col]
                if piece != '.' and not (self.animating_piece and (row, col) == self.animating_piece['start']):
                    img = pygame.image.load(f'images/{piece}.png')
                    img = pygame.transform.scale(img, (SQUARE_SIZE, SQUARE_SIZE))
                    screen.blit(img, (col*SQUARE_SIZE, row*SQUARE_SIZE))

        # Animated piece
        if self.animating_piece:
            pos = self.get_animated_position()
            if pos:
                x, y = pos
                piece = self.animating_piece['piece']
                img = pygame.image.load(f'images/{piece}.png')
                img = pygame.transform.scale(img, (SQUARE_SIZE, SQUARE_SIZE))
                screen.blit(img, (x, y + sin(pygame.time.get_ticks()/200)*5))

    def draw_ui(self, screen):
        # Clock
        clock_x = HEIGHT + 20
        pygame.draw.rect(screen, COLORS['clock'], (HEIGHT, 0, WIDTH-HEIGHT, HEIGHT))
        
        # Time displays
        font = pygame.font.Font(None, 36)
        white_text = font.render(f"White: {self.format_time(self.white_time)}", True, (255,255,255))
        black_text = font.render(f"Black: {self.format_time(self.black_time)}", True, (0,0,0))
        screen.blit(white_text, (clock_x, 20))
        screen.blit(black_text, (clock_x, 60))

        # Opening info
        if self.current_opening:
            opening_text = font.render(f"Opening: {self.current_opening}", True, (200,200,200))
            screen.blit(opening_text, (clock_x, 120))
            
            for i, move in enumerate(self.suggested_moves[:5]):
                move_text = font.render(f"{i+1}. {move}", True, (160,160,160))
                screen.blit(move_text, (clock_x, 160 + i*30))

    # Main game loop
    def run(self):
        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("PyChess")
        clock = pygame.time.Clock()

        while True:
            self.update_clocks
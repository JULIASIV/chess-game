import websockets
import asyncio
import json
import argparse

class OnlineChessClient:
    def __init__(self, server_url, game_id, player_id):
        """
        Initialize the online chess client.
        
        :param server_url: WebSocket server URL (e.g., "ws://192.168.1.100:8000")
        :param game_id: Unique game ID (e.g., "chess_game_1")
        :param player_id: Unique player ID (e.g., "player1")
        """
        self.server_url = server_url
        self.game_id = game_id
        self.player_id = player_id
        self.websocket = None
        self.opponent_move = None

    async def connect(self):
        """Connect to the WebSocket server."""
        try:
            self.websocket = await websockets.connect(
                f"{self.server_url}/ws/{self.game_id}/{self.player_id}"
            )
            print(f"Connected to server as {self.player_id}")
            asyncio.create_task(self.listen())
        except Exception as e:
            print(f"Failed to connect: {e}")

    async def listen(self):
        """Listen for messages from the server."""
        while True:
            try:
                message = await self.websocket.recv()
                data = json.loads(message)
                
                if data["type"] == "move_made":
                    # Handle opponent's move
                    self.opponent_move = data["move"]
                    print(f"Opponent moved: {self.opponent_move}")
                
                elif data["type"] == "player_joined":
                    # Notify when a player joins
                    print(f"Player {data['player_id']} joined the game!")
                
            except websockets.ConnectionClosed:
                print("Connection closed")
                break
            except Exception as e:
                print(f"Error receiving message: {e}")
                break

    async def send_move(self, move):
        """Send a move to the server."""
        if self.websocket:
            try:
                await self.websocket.send(json.dumps({
                    "type": "move",
                    "move": move,
                    "player_id": self.player_id
                }))
                print(f"Sent move: {move}")
            except Exception as e:
                print(f"Failed to send move: {e}")

    async def disconnect(self):
        """Disconnect from the server."""
        if self.websocket:
            try:
                await self.websocket.send(json.dumps({
                    "type": "disconnect",
                    "player_id": self.player_id
                }))
                await self.websocket.close()
                print("Disconnected from server")
            except Exception as e:
                print(f"Failed to disconnect: {e}")

# Example usage
async def main():
    parser = argparse.ArgumentParser(description="Online Chess Client")
    parser.add_argument("--server", type=str, default="ws://localhost:8000", help="WebSocket server URL")
    parser.add_argument("--game", type=str, default="chess_game_1", help="Game ID")
    parser.add_argument("--player", type=str, default="player1", help="Player ID")
    args = parser.parse_args()

    # Initialize client
    client = OnlineChessClient(
        server_url=args.server,
        game_id=args.game,
        player_id=args.player
    )
    
    # Connect to the server
    await client.connect()
    
    # Example: Send a move
    await client.send_move("e2e4")  # Move pawn from e2 to e4
    
    # Keep the connection alive
    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        # Disconnect when done
        await client.disconnect()

if __name__ == "__main__":
    asyncio.run(main())
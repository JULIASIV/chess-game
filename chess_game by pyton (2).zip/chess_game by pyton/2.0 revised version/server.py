from fastapi import FastAPI, WebSocket
from fastapi.staticfiles import StaticFiles
import json

# Create FastAPI app
app = FastAPI()

# Serve static files (optional, for web clients)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Game state storage
games = {}  # Stores active games
players = {}  # Stores connected players

# WebSocket endpoint for game communication
@app.websocket("/ws/{game_id}/{player_id}")
async def websocket_endpoint(websocket: WebSocket, game_id: str, player_id: str):
    # Accept the WebSocket connection
    await websocket.accept()
    
    # Add player to the game
    if game_id not in games:
        games[game_id] = {"players": {}, "state": None}
    games[game_id]["players"][player_id] = websocket
    
    # Notify all players in the game
    for pid, ws in games[game_id]["players"].items():
        await ws.send_text(json.dumps({
            "type": "player_joined",
            "player_id": player_id,
            "total_players": len(games[game_id]["players"])
        }))
    
    # Game communication loop
    while True:
        try:
            # Receive data from the WebSocket
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Handle move messages
            if message["type"] == "move":
                # Update game state
                games[game_id]["state"] = message["state"]
                
                # Broadcast the move to other players
                for pid, ws in games[game_id]["players"].items():
                    if pid != player_id:
                        await ws.send_text(json.dumps({
                            "type": "move_made",
                            "move": message["move"],
                            "state": message["state"]
                        }))
            
            # Handle disconnection
            elif message["type"] == "disconnect":
                del games[game_id]["players"][player_id]
                break
        
        except Exception as e:
            print(f"Error: {e}")
            break

# Run the server
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)